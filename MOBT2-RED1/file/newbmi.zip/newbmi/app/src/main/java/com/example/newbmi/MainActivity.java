package com.example.newbmi;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.PasswordTextBox;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.WebViewer;
import com.google.appinventor.components.runtime.util.Ev3Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.Random;

public class MainActivity extends Form implements HandlesEventDispatching {

    private

    VerticalArrangement mainArrangement;
    TextBox massBox, heightBox;
    Button calcButton, walky;
    Label resultAtBottom, headingAtTop, resultOutput;
    HorizontalArrangement dataEntryArrangement;
    protected void $define() {
        this.Sizing("Responsive");
        this.BackgroundColor(COLOR_WHITE);
        mainArrangement=new VerticalArrangement(this);
        mainArrangement.WidthPercent(100);
        mainArrangement.Height(LENGTH_FILL_PARENT);
        mainArrangement.AlignHorizontal(Component.ALIGNMENT_CENTER);

        walky = new Button(mainArrangement);
        walky.Text("Step counter  ");
        walky.HeightPercent(10);
        walky.WidthPercent(100);
        walky.TextColor(COLOR_RED);
        walky.TextAlignment(Component.ALIGNMENT_OPPOSITE);
        walky.FontSize(30);

        headingAtTop=new Label(mainArrangement);
        headingAtTop.Text("BMI calculator");
        headingAtTop.WidthPercent(100);
        headingAtTop.TextAlignment(ALIGNMENT_CENTER);
        headingAtTop.HeightPercent(10);
        headingAtTop.FontSize(40);
        headingAtTop.BackgroundColor(COLOR_PINK);
        headingAtTop.TextColor(COLOR_BLACK);

        dataEntryArrangement = new HorizontalArrangement(mainArrangement);
        dataEntryArrangement.WidthPercent(LENGTH_FILL_PARENT);
        dataEntryArrangement.HeightPercent(20);

        massBox=new TextBox(dataEntryArrangement);
        massBox.WidthPercent(50);
        massBox.HeightPercent(20);
        massBox.FontSize(40);
        massBox.TextAlignment(ALIGNMENT_CENTER);
        massBox.Hint("Weight");
        massBox.BackgroundColor(COLOR_WHITE);

        heightBox=new TextBox(dataEntryArrangement);
        heightBox.WidthPercent(50);
        heightBox.HeightPercent(20);
        heightBox.FontSize(40);
        heightBox.Hint("Height");
        heightBox.TextAlignment(ALIGNMENT_CENTER);
        heightBox.BackgroundColor(COLOR_WHITE);

        //now, the other vertically arranged components
        calcButton=new Button(mainArrangement);
        calcButton.Text("Calculate");
        calcButton.HeightPercent(20);
        calcButton.FontSize(30);
        calcButton.Width(LENGTH_FILL_PARENT);
        calcButton.BackgroundColor(COLOR_PINK);
        calcButton.TextColor(COLOR_BLACK);

        resultAtBottom=new Label(mainArrangement);
        resultAtBottom.HeightPercent(20);
        resultAtBottom.Width(LENGTH_FILL_PARENT);
        resultAtBottom.FontSize(90);
        resultAtBottom.TextAlignment(ALIGNMENT_CENTER);
        resultAtBottom.BackgroundColor(COLOR_WHITE);

        resultOutput=new Label(mainArrangement);
        resultOutput.HeightPercent(40);
        resultOutput.Width(LENGTH_FILL_PARENT);
        resultOutput.FontSize(60);
        resultOutput.TextAlignment(ALIGNMENT_CENTER);
        resultOutput.BackgroundColor(COLOR_WHITE);


        EventDispatcher.registerEventForDelegation(this, formName, "Click");
    }

    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params) {

        System.err.print("dispatchEvent: " + formName + " [" + component.toString() + "] [" + componentName + "] " + eventName);
        if (eventName.equals("Click")) {
            if (component.equals(calcButton)) {
                Integer this_person_bmi=calculateTheBMI();
                final Integer underweight_range=18;
                final Integer normal_range=24;
                final Integer overweight_range=29;
                if (this_person_bmi <= 0) {
                    resultOutput.BackgroundColor(COLOR_PINK); //error.
                }
               else if (this_person_bmi < underweight_range) { //underweight
                   resultOutput.Text("\nUnderweight");
                   resultOutput.BackgroundColor(COLOR_BLUE);
               }
               else if (this_person_bmi < normal_range) { // normal
                   resultOutput.Text("\nNormal");
                   resultOutput.BackgroundColor(COLOR_GREEN);
               }
               else if (this_person_bmi < overweight_range) { //overweight
                   resultOutput.Text("\noverweight");
                   resultOutput.BackgroundColor(COLOR_ORANGE);
               }
               else { // obese
                   resultOutput.Text("\nObese");
                   resultOutput.BackgroundColor(COLOR_RED);

               }
                return true;
            }
            else if (component.equals(walky)) {
                switchForm("StepCounter");
                return true;
            }
        }
        return false;
    }
    Integer calculateTheBMI() {
        Integer answer=0;
        Double weight=0.0, height=0.0, bmi_result=0.0;
        try {
            
        if(!massBox.Text().equals("")) {
            weight = Double.valueOf(massBox.Text());
        }
        if(!heightBox.Text().equals("")) {
            height = Double.valueOf(heightBox.Text());
        }
        bmi_result=0.0;

        if ((height != Double.valueOf(0)) && (weight != Double.valueOf(0)) ) {
            bmi_result = weight / (height * height);
            DecimalFormat df = new DecimalFormat();
            df.setMaximumFractionDigits(0); // this will round up
            resultAtBottom.Text(df.format(bmi_result));
            answer= Integer.valueOf(df.format(bmi_result));
        }
        else {
            resultAtBottom.Text("0");
            //answer=0; not needed

        }
        //return -1;

    }

        catch(Exception e) {
            resultAtBottom.Text(e.toString());
            resultAtBottom.Text("\nProvide Correct Numbers");
            resultAtBottom.FontSize(30);
            resultOutput.Text(" ");
        }
        return answer;
    }
}